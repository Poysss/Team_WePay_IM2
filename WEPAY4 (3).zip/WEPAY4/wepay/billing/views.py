from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth import login, logout
from django.contrib.auth.decorators import login_required, user_passes_test
from django.contrib import messages
from django.urls import reverse
from .forms import UserRegistrationForm, UserUpdateForm, PaymentForm, CustomAuthenticationForm
from .models import User, Bill, Payment, Notification
from django.db.models import F

def is_regular_user(user):
    return not user.is_staff and not user.is_superuser

def landing_page(request):
    if request.user.is_authenticated:
        if request.user.is_staff or request.user.is_superuser:
            return redirect('admin:index')
        return redirect('home')
    return render(request, 'landing.html')

def custom_login(request):
    if request.user.is_authenticated:
        if request.user.is_staff or request.user.is_superuser:
            logout(request)
            messages.warning(request, "Admin accounts must use the admin login page.")
            return redirect('admin:login')
        return redirect('home')
    
    if request.method == 'POST':
        form = CustomAuthenticationForm(request, data=request.POST)
        if form.is_valid():
            user = form.get_user()
            login(request, user)
            return redirect('home')
    else:
        form = CustomAuthenticationForm()
    return render(request, 'registration/login.html', {'form': form})

def register(request):
    if request.user.is_authenticated:
        return redirect('home')
        
    if request.method == 'POST':
        form = UserRegistrationForm(request.POST)
        if form.is_valid():
            user = form.save()
            login(request, user)
            messages.success(request, "Registration successful!")
            return redirect('home')
    else:
        form = UserRegistrationForm()
    return render(request, 'registration/register.html', {'form': form})

@login_required
@user_passes_test(is_regular_user, login_url='admin:login')
def home(request):
    bills = Bill.objects.filter(user=request.user).order_by('-created_at')
    return render(request, 'dashboard/home.html', {'bills': bills})

@login_required
@user_passes_test(is_regular_user, login_url='admin:login')
def bill_history(request):
    bills = Bill.objects.filter(user=request.user).order_by('-created_at')
    return render(request, 'dashboard/bill_history.html', {'bills': bills})

@login_required
@user_passes_test(is_regular_user, login_url='admin:login')
def bill_detail(request, bill_id):
    bill = get_object_or_404(Bill, id=bill_id, user=request.user)
    if request.method == 'POST':
        form = PaymentForm(request.POST)
        if form.is_valid():
            payment = form.save(commit=False)
            payment.bill = bill
            payment.user = request.user
            payment.amount_paid = bill.amount
            
            if request.user.wallet_balance >= bill.amount:
                request.user.wallet_balance = F('wallet_balance') - bill.amount
                request.user.save()
                
                payment.payment_status = 'Success'
                payment.save()
                
                bill.status = 'Paid'
                bill.save()
                
                Notification.objects.create(
                    user=request.user,
                    message=f'Payment of ${bill.amount} for {bill.bill_type} bill was successful.'
                )
                
                messages.success(request, 'Payment successful!')
                return redirect('bill_history')
            else:
                messages.error(request, 'Insufficient balance!')
    else:
        form = PaymentForm()
    
    return render(request, 'dashboard/bill_detail.html', {'bill': bill, 'form': form})

@login_required
@user_passes_test(is_regular_user, login_url='admin:login')
def notifications(request):
    notifications = Notification.objects.filter(user=request.user).order_by('-created_at')
    return render(request, 'dashboard/notification.html', {'notifications': notifications})

@login_required
@user_passes_test(is_regular_user, login_url='admin:login')
def clear_notifications(request):
    Notification.objects.filter(user=request.user).delete()
    messages.success(request, 'All notifications cleared.')
    return redirect('notifications')

@login_required
@user_passes_test(is_regular_user, login_url='admin:login')
def profile(request):
    if request.method == 'POST':
        form = UserUpdateForm(request.POST, instance=request.user)
        if form.is_valid():
            form.save()
            messages.success(request, 'Profile updated successfully!')
            return redirect('profile')
    else:
        form = UserUpdateForm(instance=request.user)
    return render(request, 'dashboard/profile.html', {'form': form})

@login_required
def user_logout(request):
    logout(request)
    messages.success(request, 'You have been logged out successfully.')
    return redirect('landing_page')

def about(request):
    return render(request, 'about.html')

def contact(request):
    return render(request, 'contact.html')