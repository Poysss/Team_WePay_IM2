from django.urls import path
from . import views

urlpatterns = [
    path('', views.landing_page, name='landing_page'),
    path('about/', views.about, name='about'),
    path('contact/', views.contact, name='contact'),
    path('register/', views.register, name='register'),
    path('login/', views.custom_login, name='login'),
    path('logout/', views.user_logout, name='logout'),
    path('home/', views.home, name='home'),
    path('bill-history/', views.bill_history, name='bill_history'),
    path('bill/<int:bill_id>/', views.bill_detail, name='bill_detail'),
    path('notifications/', views.notifications, name='notifications'),
    path('clear-notifications/', views.clear_notifications, name='clear_notifications'),
    path('profile/', views.profile, name='profile'),
]